-- MrTarget GlobalStings (enUS)
-- =====================================================================
-- Copyright (C) 2017 Lock of War, Renevatium
--

-- if GetLocale() ~= "enUS" then return; end

MRTARGET_STRINGS_EVEN = "Even the score"
MRTARGET_STRINGS_OPEN = "Type /mrt for interface options"
MRTARGET_STRINGS_TAB_NAME = "%s man"
MRTARGET_STRINGS_TAB_TITLE = "%s MAN BATTLEGROUNDS"
MRTARGET_STRINGS_RUSSIANS = "Russians"
MRTARGET_STRINGS_SCALE = "Set Scale"
MRTARGET_STRINGS_LAYOUT = "Layout"
MRTARGET_STRINGS_STYLE = "Style"
MRTARGET_STRINGS_MOVE = "RIGHT-CLICK drag to move."
MRTARGET_STRINGS_TAINT = "To avoid taint some options are disabled during battle."
MRTARGET_STRINGS_FEEDBACK = "Please send any bugs or feedback to mrtarget@lockofwar.com"
MRTARGET_STRINGS_ENABLE = "Enable MrTarget"
MRTARGET_STRINGS_ENEMIES = "Display enemy units"
MRTARGET_STRINGS_FRIENDS = "Display friendly units"
MRTARGET_STRINGS_POWER = "Display power bars"
MRTARGET_STRINGS_RANGE = "Enable range tracking"
MRTARGET_STRINGS_TARGETS = "Enable target counters"
MRTARGET_STRINGS_CYRILLIC = "What should we do with Cyrillic names?"
MRTARGET_STRINGS_SIZE = "Size does Matter"
MRTARGET_STRINGS_COLUMNS = "How many columns should there be?"
MRTARGET_STRINGS_AURAS = "Display combat auras"
MRTARGET_STRINGS_BORDERLESS = "Set to Borderless Mode"
MRTARGET_STRINGS_ICONS = "Show Unit Specification Icons"
MRTARGET_STRINGS_SLIDER_TEXT = "%s column"
