-- MrTarget GlobalStings (ruRU)
-- =====================================================================
-- Copyright (C) 2017 Lock of War, Renevatium
--

if GetLocale() ~= "ruRU" then return; end

MRTARGET_STRINGS_EVEN = "Cравнять счет."
MRTARGET_STRINGS_OPEN = "Тип /mrt для опций интерфейса"
MRTARGET_STRINGS_TAB_NAME = "%s игроков"
MRTARGET_STRINGS_TAB_TITLE = "%s игроков поле боя"
MRTARGET_STRINGS_RUSSIANS = "Россияне"
MRTARGET_STRINGS_SCALE = "Установить масштаб"
MRTARGET_STRINGS_LAYOUT = "Расположение"
MRTARGET_STRINGS_STYLE = "Cтиль"
MRTARGET_STRINGS_MOVE = "ПРАВЫЙ-ЩЕЛЧОК перетащите, чтобы переместить."
MRTARGET_STRINGS_TAINT = "Во избежание порчи некоторые опции отключены во время боя."
MRTARGET_STRINGS_FEEDBACK = "Пожалуйста, присылайте любые ошибки или отзывы на mrtarget@lockofwar.com"
MRTARGET_STRINGS_ENABLE = "Включить MrTarget"
MRTARGET_STRINGS_ENEMIES = "Показать врагов"
MRTARGET_STRINGS_FRIENDS = "Показать друзей"
MRTARGET_STRINGS_POWER = "Индикаторы ресурсов"
MRTARGET_STRINGS_RANGE = "Включить отслеживание дальность"
MRTARGET_STRINGS_TARGETS = "Включить целевые счетчики"
MRTARGET_STRINGS_CYRILLIC = "Что нам делать с кириллическими именами?"
MRTARGET_STRINGS_SIZE = "Задать размер"
MRTARGET_STRINGS_COLUMNS = "Сколько столбцов должно быть?"
MRTARGET_STRINGS_AURAS = "Показывать боевые ауры"
MRTARGET_STRINGS_BORDERLESS = "Переключиться в режим без полей"
MRTARGET_STRINGS_ICONS = "Показать значки спецификации"
MRTARGET_STRINGS_SLIDER_TEXT = "%s столбец"
